export declare function matchingPasswords(passwordKey: string, confirmPasswordKey: string): (group: any) => {
    [key: string]: any;
};
